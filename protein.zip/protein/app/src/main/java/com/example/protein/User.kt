package com.example.protein

class User(val login: String, val email: String, val firstname: String, val lastname: String, val pass: String, val repeat: String) {
}